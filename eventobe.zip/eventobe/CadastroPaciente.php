<?php 

include('conexao.php');

$nome=              $mysqli->real_escape_string($_POST['pnome']);
$pdata=             $_POST['pdata'];
$sexo=              $_POST['psexo'];
$cep=               $mysqli->real_escape_string($_POST['cep']);
$uf=                $_POST['estado'];
$cidade=            $mysqli->real_escape_string($_POST['cidade']);
$endereco=          $mysqli->real_escape_string($_POST['endereco']);
$bairro=            $mysqli->real_escape_string($_POST['bairro']);
$com=               $mysqli->real_escape_string($_POST['complemento']);
$telefone=          $mysqli->real_escape_string($_POST['telefone']);
$email=             $mysqli->real_escape_string($_POST['email']);
$peso=              $mysqli->real_escape_string($_POST['peso']);
$altura=            $mysqli->real_escape_string($_POST['altura']);
$fuma=              $_POST['fuma'];
$bebe=              $_POST['bebe'];
$hiper=             $_POST['hiper'];
$diab=              $_POST['diab'];
$dac=               $_POST['dac'];
$outro=             $mysqli->real_escape_string($_POST['doenca']);
$med=               $_POST['med'];
$rem=               $mysqli->real_escape_string($_POST['rem']);



$pac = "INSERT INTO paciente
(Nome_Paciente, DTN_Paciente,Sex_Paciente,CEP_Paciente,UF_Paciente,Cid_Paciente,End_Paciente,Bai_Paciente,Com_Paciente,Fone_Paciente,Email_Paciente,Pes_Paciente,Alt_Paciente,Fuma_Paciente,Bebe_Paciente,Hiper_Paciente,Diab_Paciente,Dac_Paciente,Doe_Paciente,Med_Paciente,Rem_Paciente) 
        VALUES ('$nome','$pdata','$sexo','$cep','$uf','$cidade','$endereco','$bairro','$com','$telefone','$email','$peso','$altura','$fuma','$bebe','$hiper','$diab','$dac','$outro','$med','$rem')";

if(mysqli_query($mysqli, $pac)){
    header('location: homeView.php');
}
else{
    echo "Erro".mysqli_connect_error($mysqli);
}

mysqli_close($mysqli);



?>