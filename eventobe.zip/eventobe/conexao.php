<?php

$servername=    'localhost';
$username=      'root';
$password=      '';
$dbname=        'bemestar';

$mysqli= mysqli_connect($servername, $username, $password, $dbname);
if($mysqli->error){
    die("Houve um erro: " . $mysqli->error);
}

?>  