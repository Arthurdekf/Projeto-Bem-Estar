<?php
include('conexao.php');

if(isset($_POST['ID']) || isset($_POST['senha'])) {

    if(strlen($_POST['ID']) == 0) {
        echo "Preencha seu e-mail";
    } else if(strlen($_POST['senha']) == 0) {
        echo "Preencha sua senha";
    } else {

        $id = $mysqli->real_escape_string($_POST['ID']);
        $senha = $mysqli->real_escape_string($_POST['senha']);

        $sql_code = "SELECT * FROM usuario WHERE Cod_Usuario = '$id' AND Senha = '$senha'";
        $sql_query = $mysqli->query($sql_code) or die("Falha na execução do código SQL: " . $mysqli->error);

        $quantidade = $sql_query->num_rows;

        if($quantidade == 1) {
            
            $usuario = $sql_query->fetch_assoc();

            if(!isset($_SESSION)) {
                session_start();
            }

            $_SESSION['id'] = $usuario['Cod_Usuario'];
            $_SESSION['nome'] = $usuario['Nome'];

            header("Location: homeView.php");

        } else {
           
        }

    }

}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/estilo.css">
    <style>

        input:invalid{
            color: red;
            animation: shake .3s;  

        }

        @keyframes shake{
            25%{
                transform: translateX(4px);
            }

            50%{
                transform: translateX(-4px);
            }

            75%{
                transform: translateX(4px);
            }
        }
    </style>   
    <title>Login</title>
</head>
<body>
   <?php include('nav.html'); ?>

      <div class="row">
        <div class="col-4"></div>
        <div class="col-4">
            <center><h1>Login</h1></center>
            
            <div class="form-group">
                <form action="" method="POST">
                        <label for="ID">ID:</label>
                        <input class="form-control" type="text" id="ID" name="ID" placeholder="Digite seu ID..." required name>
                    </div>
                    <div cLass="form-group">
                        <label for="senha">Senha:</label>
                        <input class="form-control" type="password" id="senha" name="senha" placeholder="Digite sua senha..." required name>
                    </div>
                    <div class="form-group text-center">
                        <button type="submit" class="btn">Logar</button>
                        <a href="CadastroView.php"><p>Cadastre-se!</p></a>
                </form>
            </div>
            
        </div>
        </div>  
<script src="js/jquery-3.3.1.slim.min.js"></script>
<script src="js/bootstrap.min.js"></script>  
</body>
</html>