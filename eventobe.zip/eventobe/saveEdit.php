<?php 
    include("conexao.php");

    if(isset($_POST['update'])){

        $id=                $_POST['id'];
        $nome=              $mysqli->real_escape_string($_POST['pnome']);
        $pdata=             $_POST['pdata'];
        $sexo=              $_POST['psexo'];
        $cep=               $mysqli->real_escape_string($_POST['cep']);
        $uf=                $_POST['estado'];
        $cidade=            $mysqli->real_escape_string($_POST['cidade']);
        $endereco=          $mysqli->real_escape_string($_POST['endereco']);
        $bairro=            $mysqli->real_escape_string($_POST['bairro']);
        $com=               $mysqli->real_escape_string($_POST['complemento']);
        $telefone=          $mysqli->real_escape_string($_POST['telefone']);
        $email=             $mysqli->real_escape_string($_POST['email']);
        $peso=              $mysqli->real_escape_string($_POST['peso']);
        $altura=            $mysqli->real_escape_string($_POST['altura']);
        $fuma=              $_POST['fuma'];
        $bebe=              $_POST['bebe'];
        $hiper=             $_POST['hiper'];
        $diab=              $_POST['diab'];
        $dac=               $_POST['dac'];
        $outro=             $mysqli->real_escape_string($_POST['doenca']);
        $med=               $_POST['med'];
        $rem=               $mysqli->real_escape_string($_POST['rem']);


        $sqlUpdate = "UPDATE paciente SET Nome_Paciente = '$nome', DTN_Paciente = '$pdata',CEP_Paciente = '$cep',Cid_Paciente = '$cidade',End_Paciente = '$endereco',Bai_Paciente = '$bairro',Com_Paciente = '$com',Fone_Paciente = '$telefone',Email_Paciente = '$email',Pes_Paciente = '$peso',Alt_Paciente = '$altura',Doe_Paciente = '$outro', Rem_Paciente = '$rem' WHERE Cod_Paciente = '$id'";
    

        $result = $mysqli->query($sqlUpdate);

}
header('location: homeView.php');
?>