<?php 

include('conexao.php');


$nome=$mysqli->real_escape_string($_POST['nome']);
$data=$_POST['data'];
$senha=$mysqli->real_escape_string($_POST['senha']);
$curso=$_POST['curso'];


$sql = "INSERT INTO usuario(FKID_Curso,Nome,DTN,Senha) VALUES ('$curso','$nome','$data','$senha')";

if(mysqli_query($mysqli, $sql)){
    header('location: Bemvindo.php');
}
else{
    echo "Erro".mysqli_connect_error($mysqli);
}

mysqli_close($mysqli);



?>